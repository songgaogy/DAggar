from __future__ import annotations

import glob
import os
from dataclasses import dataclass
from typing import Any

import h5py
import numpy as np
import torch
from hydra.utils import to_absolute_path
from torch.utils.data import Dataset
from tqdm import tqdm

from robosuite.discriminator.dyn_bce.flow_encoder import FrozenFlowMultitaskEncoder
from robosuite.discriminator.dyn_bce.task_registry import ordered_task_names


DATA_TYPE_ORDER = ["expert", "success_rollout", "fail_rollout"]


@dataclass(frozen=True)
class SplitCounts:
    num_expert_traj: int
    num_success_traj: int
    num_fail_traj: int

    def by_data_type(self) -> dict[str, int]:
        return {
            "expert": int(self.num_expert_traj),
            "success_rollout": int(self.num_success_traj),
            "fail_rollout": int(self.num_fail_traj),
        }


@dataclass(frozen=True)
class TaskDataSpec:
    task_name: str
    expert_dir: str
    success_rollout_dir: str
    fail_rollout_dir: str
    train: SplitCounts
    val: SplitCounts
    test: SplitCounts

    def dir_for(self, data_type: str) -> str:
        if data_type == "expert":
            return self.expert_dir
        if data_type == "success_rollout":
            return self.success_rollout_dir
        if data_type == "fail_rollout":
            return self.fail_rollout_dir
        raise KeyError(f"Unsupported data_type: {data_type}")


@dataclass(frozen=True)
class DemoRef:
    task_name: str
    data_type: str
    split: str
    file_path: str
    demo_key: str


@dataclass
class EncodedTrajectory:
    task_name: str
    data_type: str
    split: str
    latents: np.ndarray
    actions: np.ndarray
    risk_targets: np.ndarray
    hard_labels: np.ndarray
    occ_weights: np.ndarray
    fuse_weights: np.ndarray
    dyn_weights: np.ndarray


@dataclass(frozen=True)
class TransitionRef:
    traj_idx: int
    step_idx: int


class DynBCETransitionDataset(Dataset):
    def __init__(
        self,
        trajectories: list[EncodedTrajectory],
        task_to_index: dict[str, int],
        transition_horizon: int,
    ) -> None:
        super().__init__()
        self.trajectories = list(trajectories)
        self.task_to_index = dict(task_to_index)
        self.transition_horizon = int(transition_horizon)
        if self.transition_horizon <= 0:
            raise ValueError("transition_horizon must be >= 1")

        self._refs: list[TransitionRef] = []
        for traj_idx, traj in enumerate(self.trajectories):
            usable = min(
                int(traj.latents.shape[0]),
                int(traj.actions.shape[0]),
            ) - self.transition_horizon
            if usable <= 0:
                continue
            for step_idx in range(usable):
                self._refs.append(TransitionRef(traj_idx=traj_idx, step_idx=step_idx))
        if not self._refs:
            raise RuntimeError("No transition samples available for DynBCETransitionDataset")

    def __len__(self) -> int:
        return len(self._refs)

    def __getitem__(self, index: int) -> dict[str, torch.Tensor]:
        ref = self._refs[index]
        traj = self.trajectories[ref.traj_idx]
        t = ref.step_idx
        h = self.transition_horizon

        sample = {
            "current_latent": torch.from_numpy(traj.latents[t].astype(np.float32)),
            "next_latent": torch.from_numpy(traj.latents[t + h].astype(np.float32)),
            "action_sequence": torch.from_numpy(traj.actions[t : t + h].astype(np.float32)),
            "risk_target": torch.tensor(float(traj.risk_targets[t]), dtype=torch.float32),
            "hard_label": torch.tensor(int(traj.hard_labels[t]), dtype=torch.int64),
            "occ_weight": torch.tensor(float(traj.occ_weights[t]), dtype=torch.float32),
            "fuse_weight": torch.tensor(float(traj.fuse_weights[t]), dtype=torch.float32),
            "dyn_weight": torch.tensor(float(traj.dyn_weights[t]), dtype=torch.float32),
            "task_index": torch.tensor(self.task_to_index[traj.task_name], dtype=torch.int64),
            "data_type_index": torch.tensor(DATA_TYPE_ORDER.index(traj.data_type), dtype=torch.int64),
        }
        return sample


def _list_hdf5_demo_refs(task_name: str, data_type: str, data_dir: str) -> list[tuple[str, str]]:
    if not os.path.isdir(data_dir):
        raise FileNotFoundError(f"Directory not found for {task_name}/{data_type}: {data_dir}")
    refs: list[tuple[str, str]] = []
    hdf5_files = sorted(glob.glob(os.path.join(data_dir, "*.hdf5")))
    if not hdf5_files:
        raise FileNotFoundError(f"No .hdf5 files found in: {data_dir}")
    for file_path in hdf5_files:
        with h5py.File(file_path, "r") as file_handle:
            if "demos" not in file_handle:
                continue
            for demo_key in sorted(file_handle["demos"].keys()):
                refs.append((file_path, demo_key))
    if not refs:
        raise RuntimeError(f"No demos found under {data_dir}")
    return refs


def _split_refs_with_counts(
    refs: list[tuple[str, str]],
    train_count: int,
    val_count: int,
    test_count: int,
    seed: int,
) -> dict[str, list[tuple[str, str]]]:
    total_needed = int(train_count) + int(val_count) + int(test_count)
    if total_needed <= 0:
        return {"train": [], "val": [], "test": []}
    if len(refs) < total_needed:
        raise ValueError(
            f"Requested {total_needed} trajectories but only found {len(refs)}"
        )
    rng = np.random.default_rng(int(seed))
    indices = np.arange(len(refs))
    rng.shuffle(indices)
    selected = [refs[idx] for idx in indices[:total_needed]]

    train_end = int(train_count)
    val_end = train_end + int(val_count)
    return {
        "train": selected[:train_end],
        "val": selected[train_end:val_end],
        "test": selected[val_end : val_end + int(test_count)],
    }


def _sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-x))


def _build_fail_schedule(
    num_steps: int,
    fail_onset_ratio: float,
    risk_temperature: float,
    occ_prefix_min_weight: float,
    fuse_prefix_min_weight: float,
) -> dict[str, np.ndarray]:
    if num_steps <= 0:
        raise ValueError(f"num_steps must be positive, got {num_steps}")

    if num_steps == 1:
        progress = np.asarray([1.0], dtype=np.float32)
    else:
        progress = np.linspace(0.0, 1.0, num_steps, dtype=np.float32)

    center = float(fail_onset_ratio)
    temperature = max(float(risk_temperature), 1e-4)
    sigmoid_curve = _sigmoid((progress - center) / temperature).astype(np.float32)
    risk = sigmoid_curve
    occ_weights = (float(occ_prefix_min_weight) + (1.0 - float(occ_prefix_min_weight)) * sigmoid_curve).astype(np.float32)
    fuse_weights = (float(fuse_prefix_min_weight) + (1.0 - float(fuse_prefix_min_weight)) * sigmoid_curve).astype(np.float32)
    dyn_weights = np.zeros(num_steps, dtype=np.float32)
    hard_labels = (sigmoid_curve >= 0.5).astype(np.int64)

    return {
        "risk_targets": risk,
        "hard_labels": hard_labels,
        "occ_weights": occ_weights,
        "fuse_weights": fuse_weights,
        "dyn_weights": dyn_weights,
    }


def _build_positive_schedule(num_steps: int) -> dict[str, np.ndarray]:
    zeros = np.zeros(num_steps, dtype=np.float32)
    ones = np.ones(num_steps, dtype=np.float32)
    return {
        "risk_targets": zeros,
        "hard_labels": np.zeros(num_steps, dtype=np.int64),
        "occ_weights": ones,
        "fuse_weights": ones,
        "dyn_weights": ones,
    }


def _cfg_get(cfg: Any, key: str, default=None):
    if isinstance(cfg, dict):
        return cfg.get(key, default)
    return getattr(cfg, key, default)


def _split_counts_from_cfg(cfg: Any) -> SplitCounts:
    return SplitCounts(
        num_expert_traj=int(_cfg_get(cfg, "num_expert_traj")),
        num_success_traj=int(_cfg_get(cfg, "num_success_traj")),
        num_fail_traj=int(_cfg_get(cfg, "num_fail_traj")),
    )


def parse_task_specs(cfg_data: Any) -> dict[str, TaskDataSpec]:
    specs: dict[str, TaskDataSpec] = {}
    tasks_cfg = _cfg_get(cfg_data, "tasks")
    for task_name in ordered_task_names(list(tasks_cfg.keys())):
        task_cfg = tasks_cfg[task_name]
        specs[task_name] = TaskDataSpec(
            task_name=task_name,
            expert_dir=to_absolute_path(str(_cfg_get(task_cfg, "expert_dir"))),
            success_rollout_dir=to_absolute_path(str(_cfg_get(task_cfg, "success_rollout_dir"))),
            fail_rollout_dir=to_absolute_path(str(_cfg_get(task_cfg, "fail_rollout_dir"))),
            train=_split_counts_from_cfg(_cfg_get(task_cfg, "train")),
            val=_split_counts_from_cfg(_cfg_get(task_cfg, "val")),
            test=_split_counts_from_cfg(_cfg_get(task_cfg, "test")),
        )
    return specs


def _encode_selected_refs(
    refs: list[DemoRef],
    encoder: FrozenFlowMultitaskEncoder,
    cache_dir: str,
    fail_onset_ratio: float,
    risk_temperature: float,
    occ_prefix_min_weight: float,
    fuse_prefix_min_weight: float,
) -> list[EncodedTrajectory]:
    trajectories: list[EncodedTrajectory] = []
    for ref in tqdm(refs, desc="encoding dyn_bce trajectories"):
        encoded = encoder.load_or_encode_demo(
            cache_root=cache_dir,
            task_name=ref.task_name,
            file_path=ref.file_path,
            demo_key=ref.demo_key,
        )
        num_transitions = max(min(encoded.latents.shape[0], encoded.actions.shape[0]) - 1, 0)
        if num_transitions <= 0:
            continue
        if ref.data_type == "fail_rollout":
            schedule = _build_fail_schedule(
                num_steps=num_transitions,
                fail_onset_ratio=float(fail_onset_ratio),
                risk_temperature=float(risk_temperature),
                occ_prefix_min_weight=float(occ_prefix_min_weight),
                fuse_prefix_min_weight=float(fuse_prefix_min_weight),
            )
        else:
            schedule = _build_positive_schedule(num_steps=num_transitions)

        trajectories.append(
            EncodedTrajectory(
                task_name=ref.task_name,
                data_type=ref.data_type,
                split=ref.split,
                latents=encoded.latents.astype(np.float32),
                actions=encoded.actions.astype(np.float32),
                risk_targets=schedule["risk_targets"],
                hard_labels=schedule["hard_labels"],
                occ_weights=schedule["occ_weights"],
                fuse_weights=schedule["fuse_weights"],
                dyn_weights=schedule["dyn_weights"],
            )
        )
    return trajectories


def _build_ref_splits(
    task_specs: dict[str, TaskDataSpec],
    seed: int,
) -> tuple[dict[str, list[DemoRef]], dict[str, dict[str, dict[str, int]]]]:
    split_refs = {"train": [], "val": [], "test": []}
    split_summary: dict[str, dict[str, dict[str, int]]] = {}

    for task_offset, task_name in enumerate(ordered_task_names(list(task_specs.keys()))):
        spec = task_specs[task_name]
        split_summary[task_name] = {"train": {}, "val": {}, "test": {}}
        split_cfgs = {"train": spec.train, "val": spec.val, "test": spec.test}
        for data_type_idx, data_type in enumerate(DATA_TYPE_ORDER):
            refs = _list_hdf5_demo_refs(task_name=task_name, data_type=data_type, data_dir=spec.dir_for(data_type))
            chosen = _split_refs_with_counts(
                refs=refs,
                train_count=split_cfgs["train"].by_data_type()[data_type],
                val_count=split_cfgs["val"].by_data_type()[data_type],
                test_count=split_cfgs["test"].by_data_type()[data_type],
                seed=int(seed + task_offset * 97 + data_type_idx * 17),
            )
            for split_name in ["train", "val", "test"]:
                split_summary[task_name][split_name][data_type] = int(len(chosen[split_name]))
                for file_path, demo_key in chosen[split_name]:
                    split_refs[split_name].append(
                        DemoRef(
                            task_name=task_name,
                            data_type=data_type,
                            split=split_name,
                            file_path=file_path,
                            demo_key=demo_key,
                        )
                    )
    return split_refs, split_summary


def build_datasets(
    cfg_data: Any,
    cfg_labels: Any,
    encoder: FrozenFlowMultitaskEncoder,
    seed: int,
) -> tuple[dict[str, DynBCETransitionDataset], dict[str, int], dict[str, Any]]:
    task_specs = parse_task_specs(cfg_data)
    split_refs, split_summary = _build_ref_splits(task_specs=task_specs, seed=int(seed))

    cache_dir = to_absolute_path(str(_cfg_get(cfg_data, "cache_dir")))
    trajectories_by_split: dict[str, list[EncodedTrajectory]] = {}
    for split_name in ["train", "val", "test"]:
        trajectories_by_split[split_name] = _encode_selected_refs(
            refs=split_refs[split_name],
            encoder=encoder,
            cache_dir=cache_dir,
            fail_onset_ratio=float(_cfg_get(cfg_labels, "fail_onset_ratio")),
            risk_temperature=float(_cfg_get(cfg_labels, "risk_temperature")),
            occ_prefix_min_weight=float(_cfg_get(cfg_labels, "occ_prefix_min_weight")),
            fuse_prefix_min_weight=float(_cfg_get(cfg_labels, "fuse_prefix_min_weight")),
        )

    task_names = ordered_task_names(list(task_specs.keys()))
    task_to_index = {task_name: idx for idx, task_name in enumerate(task_names)}
    transition_horizon = int(_cfg_get(cfg_data, "transition_horizon", 1))

    datasets = {
        split_name: DynBCETransitionDataset(
            trajectories=trajectories_by_split[split_name],
            task_to_index=task_to_index,
            transition_horizon=transition_horizon,
        )
        for split_name in ["train", "val", "test"]
    }
    metadata = {
        "task_names": task_names,
        "split_summary": split_summary,
        "num_trajectories": {
            split_name: int(len(trajectories_by_split[split_name]))
            for split_name in ["train", "val", "test"]
        },
        "num_transitions": {
            split_name: int(len(datasets[split_name]))
            for split_name in ["train", "val", "test"]
        },
        "cache_dir": cache_dir,
        "transition_horizon": transition_horizon,
    }
    return datasets, task_to_index, metadata
