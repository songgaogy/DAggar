from __future__ import annotations

import numpy as np

try:
    from sklearn.metrics import average_precision_score, roc_auc_score
except Exception:  # pragma: no cover
    average_precision_score = None
    roc_auc_score = None


def _safe_numpy(x) -> np.ndarray:
    arr = np.asarray(x)
    return arr.reshape(-1)


def compute_binary_metrics(
    probs,
    labels,
    threshold: float = 0.5,
) -> dict[str, float]:
    probs_np = _safe_numpy(probs).astype(np.float64)
    labels_np = _safe_numpy(labels).astype(np.int64)
    if probs_np.size == 0:
        return {}

    preds_np = (probs_np >= float(threshold)).astype(np.int64)
    accuracy = float((preds_np == labels_np).mean())

    tp = int(np.sum((preds_np == 1) & (labels_np == 1)))
    fp = int(np.sum((preds_np == 1) & (labels_np == 0)))
    fn = int(np.sum((preds_np == 0) & (labels_np == 1)))
    precision = float(tp / max(tp + fp, 1))
    recall = float(tp / max(tp + fn, 1))
    f1 = float(2.0 * precision * recall / max(precision + recall, 1e-8))

    metrics = {
        "accuracy": accuracy,
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "positive_rate": float(preds_np.mean()),
        "label_rate": float(labels_np.mean()),
    }

    if not labels_np.min() == labels_np.max():
        if roc_auc_score is not None:
            metrics["auroc"] = float(roc_auc_score(labels_np, probs_np))
        if average_precision_score is not None:
            metrics["auprc"] = float(average_precision_score(labels_np, probs_np))
    return metrics
