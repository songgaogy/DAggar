from __future__ import annotations

import copy
from dataclasses import dataclass

import torch
import torch.nn as nn


def build_mlp(
    input_dim: int,
    hidden_dim: int,
    output_dim: int,
    depth: int,
    dropout: float,
) -> nn.Sequential:
    layers: list[nn.Module] = []
    cur_dim = int(input_dim)
    for _ in range(max(int(depth) - 1, 0)):
        layers.append(nn.Linear(cur_dim, hidden_dim))
        layers.append(nn.GELU())
        if float(dropout) > 0.0:
            layers.append(nn.Dropout(dropout))
        cur_dim = int(hidden_dim)
    layers.append(nn.Linear(cur_dim, output_dim))
    return nn.Sequential(*layers)


class ActionSequenceEncoder(nn.Module):
    def __init__(
        self,
        action_dim: int,
        model_dim: int,
        hidden_dim: int,
        num_layers: int,
        num_heads: int,
        dropout: float,
        max_horizon: int,
    ) -> None:
        super().__init__()
        self.action_dim = int(action_dim)
        self.model_dim = int(model_dim)
        self.max_horizon = int(max_horizon)
        self.action_proj = nn.Linear(self.action_dim, self.model_dim)
        self.cls_token = nn.Parameter(torch.zeros(1, 1, self.model_dim))
        self.pos_embedding = nn.Parameter(torch.randn(1, self.max_horizon + 1, self.model_dim) * 0.02)
        layer = nn.TransformerEncoderLayer(
            d_model=self.model_dim,
            nhead=int(num_heads),
            dim_feedforward=int(hidden_dim),
            dropout=float(dropout),
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(layer, num_layers=int(num_layers))
        self.norm = nn.LayerNorm(self.model_dim)

    def forward(self, action_sequence: torch.Tensor) -> torch.Tensor:
        if not action_sequence.ndim == 3:
            raise ValueError(f"Expected action_sequence to be (B,H,A), got {action_sequence.shape}")
        batch_size, horizon, _ = action_sequence.shape
        if horizon > self.max_horizon:
            raise ValueError(f"horizon {horizon} exceeds max_horizon={self.max_horizon}")
        action_tokens = self.action_proj(action_sequence)
        cls_token = self.cls_token.expand(batch_size, -1, -1)
        tokens = torch.cat([cls_token, action_tokens], dim=1)
        tokens = tokens + self.pos_embedding[:, : tokens.shape[1], :]
        encoded = self.encoder(tokens)
        return self.norm(encoded[:, 0])


class RunningScalarCalibrator(nn.Module):
    def __init__(self, momentum: float = 0.05, eps: float = 1e-6) -> None:
        super().__init__()
        self.momentum = float(momentum)
        self.eps = float(eps)
        self.register_buffer("running_mean", torch.zeros(1))
        self.register_buffer("running_var", torch.ones(1))
        self.register_buffer("initialized", torch.zeros(1, dtype=torch.bool))

    def forward(self, values: torch.Tensor) -> torch.Tensor:
        x = values.reshape(-1).float()
        if self.training:
            batch_mean = x.mean()
            batch_var = x.var(unbiased=False) if x.numel() > 1 else x.new_ones(())
            if not bool(self.initialized.item()):
                self.running_mean.copy_(batch_mean.detach().view_as(self.running_mean))
                self.running_var.copy_(batch_var.detach().view_as(self.running_var).clamp_min(self.eps))
                self.initialized.fill_(True)
            else:
                self.running_mean.mul_(1.0 - self.momentum).add_(batch_mean.detach() * self.momentum)
                self.running_var.mul_(1.0 - self.momentum).add_(
                    batch_var.detach().clamp_min(self.eps) * self.momentum
                )
        normalized = (x - self.running_mean) / self.running_var.sqrt().clamp_min(self.eps)
        return torch.sigmoid(normalized)


@dataclass
class DynBCEForwardOutput:
    occ_logit: torch.Tensor
    judge_logit: torch.Tensor
    occ_private: torch.Tensor
    dyn_private_mean: torch.Tensor
    ensemble_mean: torch.Tensor
    ensemble_logvar: torch.Tensor
    ema_target: torch.Tensor
    occ_evidence: torch.Tensor
    dyn_evidence: torch.Tensor
    epi_evidence: torch.Tensor
    occ_prob: torch.Tensor
    dyn_residual: torch.Tensor
    epi_variance: torch.Tensor


class DynBCEModel(nn.Module):
    def __init__(
        self,
        latent_dim: int,
        action_dim: int,
        num_tasks: int,
        shared_dim: int,
        occ_private_dim: int,
        dyn_private_dim: int,
        task_embed_dim: int,
        trunk_hidden_dim: int,
        head_hidden_dim: int,
        action_model_dim: int,
        action_num_layers: int,
        action_num_heads: int,
        action_dropout: float,
        max_action_horizon: int,
        ensemble_size: int,
        judge_hidden_dim: int,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.latent_dim = int(latent_dim)
        self.action_dim = int(action_dim)
        self.num_tasks = int(num_tasks)
        self.ensemble_size = int(ensemble_size)
        self.task_embedding = nn.Embedding(self.num_tasks, int(task_embed_dim))
        self.input_norm = nn.LayerNorm(self.latent_dim)

        trunk_input_dim = self.latent_dim + int(task_embed_dim)
        self.shared_encoder = nn.Sequential(
            nn.LayerNorm(trunk_input_dim),
            build_mlp(
                input_dim=trunk_input_dim,
                hidden_dim=int(trunk_hidden_dim),
                output_dim=int(shared_dim),
                depth=3,
                dropout=float(dropout),
            ),
            nn.LayerNorm(int(shared_dim)),
        )
        self.occ_private_encoder = nn.Sequential(
            nn.LayerNorm(trunk_input_dim),
            build_mlp(
                input_dim=trunk_input_dim,
                hidden_dim=int(trunk_hidden_dim),
                output_dim=int(occ_private_dim),
                depth=3,
                dropout=float(dropout),
            ),
            nn.LayerNorm(int(occ_private_dim)),
        )
        self.dyn_private_encoders = nn.ModuleList(
            [
                nn.Sequential(
                    nn.LayerNorm(trunk_input_dim),
                    build_mlp(
                        input_dim=trunk_input_dim,
                        hidden_dim=int(trunk_hidden_dim),
                        output_dim=int(dyn_private_dim),
                        depth=3,
                        dropout=float(dropout),
                    ),
                    nn.LayerNorm(int(dyn_private_dim)),
                )
                for _ in range(self.ensemble_size)
            ]
        )
        self.ema_dyn_private_encoders = copy.deepcopy(self.dyn_private_encoders)
        for param in self.ema_dyn_private_encoders.parameters():
            param.requires_grad = False

        self.action_encoder = ActionSequenceEncoder(
            action_dim=self.action_dim,
            model_dim=int(action_model_dim),
            hidden_dim=int(head_hidden_dim),
            num_layers=int(action_num_layers),
            num_heads=int(action_num_heads),
            dropout=float(action_dropout),
            max_horizon=int(max_action_horizon),
        )
        occ_input_dim = int(shared_dim) + int(occ_private_dim) + int(task_embed_dim)
        self.occupancy_head = nn.Sequential(
            nn.LayerNorm(occ_input_dim),
            build_mlp(
                input_dim=occ_input_dim,
                hidden_dim=int(head_hidden_dim),
                output_dim=1,
                depth=3,
                dropout=float(dropout),
            ),
        )
        dyn_input_dim = int(shared_dim) + int(dyn_private_dim) + int(action_model_dim) + int(task_embed_dim)
        self.dynamics_heads = nn.ModuleList(
            [
                build_mlp(
                    input_dim=dyn_input_dim,
                    hidden_dim=int(head_hidden_dim),
                    output_dim=int(dyn_private_dim * 2),
                    depth=3,
                    dropout=float(dropout),
                )
                for _ in range(self.ensemble_size)
            ]
        )
        self.judge = nn.Sequential(
            nn.LayerNorm(3),
            nn.Linear(3, int(judge_hidden_dim)),
            nn.GELU(),
            nn.Dropout(float(dropout)),
            nn.Linear(int(judge_hidden_dim), int(judge_hidden_dim)),
            nn.GELU(),
            nn.Linear(int(judge_hidden_dim), 1),
        )

        self.occ_calibrator = RunningScalarCalibrator()
        self.dyn_calibrator = RunningScalarCalibrator()
        self.epi_calibrator = RunningScalarCalibrator()

    def _concat_task(self, latent: torch.Tensor, task_embedding: torch.Tensor) -> torch.Tensor:
        return torch.cat([self.input_norm(latent), task_embedding], dim=-1)

    def _encode_ema_target(self, next_latent: torch.Tensor, task_embedding: torch.Tensor) -> torch.Tensor:
        ema_input = self._concat_task(next_latent, task_embedding)
        ema_latents = [encoder(ema_input) for encoder in self.ema_dyn_private_encoders]
        return torch.stack(ema_latents, dim=0).mean(dim=0)

    def update_ema(self, decay: float) -> None:
        with torch.no_grad():
            for online_module, ema_module in zip(self.dyn_private_encoders, self.ema_dyn_private_encoders):
                for online_param, ema_param in zip(online_module.parameters(), ema_module.parameters()):
                    ema_param.data.mul_(float(decay)).add_(online_param.data * (1.0 - float(decay)))
                for online_buffer, ema_buffer in zip(online_module.buffers(), ema_module.buffers()):
                    ema_buffer.data.copy_(online_buffer.data)

    def forward(
        self,
        current_latent: torch.Tensor,
        next_latent: torch.Tensor,
        action_sequence: torch.Tensor,
        task_index: torch.Tensor,
    ) -> DynBCEForwardOutput:
        task_embedding = self.task_embedding(task_index)
        current_input = self._concat_task(current_latent, task_embedding)
        shared_latent = self.shared_encoder(current_input)
        occ_private = self.occ_private_encoder(current_input)
        dyn_private = [encoder(current_input) for encoder in self.dyn_private_encoders]
        dyn_private_stack = torch.stack(dyn_private, dim=0)
        dyn_private_mean = dyn_private_stack.mean(dim=0)

        occ_input = torch.cat([shared_latent, occ_private, task_embedding], dim=-1)
        occ_logit = self.occupancy_head(occ_input).squeeze(-1)
        occ_positive_prob = torch.sigmoid(occ_logit)
        occ_prob = 1.0 - occ_positive_prob

        action_feature = self.action_encoder(action_sequence)
        ensemble_means = []
        ensemble_logvars = []
        for ensemble_idx, head in enumerate(self.dynamics_heads):
            dyn_input = torch.cat(
                [
                    shared_latent,
                    dyn_private_stack[ensemble_idx],
                    action_feature,
                    task_embedding,
                ],
                dim=-1,
            )
            pred = head(dyn_input)
            mean, logvar = pred.chunk(2, dim=-1)
            ensemble_means.append(mean)
            ensemble_logvars.append(logvar.clamp(min=-8.0, max=6.0))
        ensemble_mean = torch.stack(ensemble_means, dim=0)
        ensemble_logvar = torch.stack(ensemble_logvars, dim=0)

        with torch.no_grad():
            ema_target = self._encode_ema_target(next_latent=next_latent, task_embedding=task_embedding)

        ensemble_mean_avg = ensemble_mean.mean(dim=0)
        dyn_residual = torch.sqrt(torch.mean((ensemble_mean_avg - ema_target) ** 2, dim=-1) + 1e-6)
        epi_variance = torch.mean(
            torch.var(ensemble_mean, dim=0, unbiased=False),
            dim=-1,
        )

        occ_evidence = self.occ_calibrator(occ_prob).detach()
        dyn_evidence = self.dyn_calibrator(dyn_residual).detach()
        epi_evidence = self.epi_calibrator(epi_variance).detach()

        judge_input = torch.stack([occ_evidence, dyn_evidence, epi_evidence], dim=-1)
        judge_logit = self.judge(judge_input).squeeze(-1)
        return DynBCEForwardOutput(
            occ_logit=occ_logit,
            judge_logit=judge_logit,
            occ_private=occ_private,
            dyn_private_mean=dyn_private_mean,
            ensemble_mean=ensemble_mean,
            ensemble_logvar=ensemble_logvar,
            ema_target=ema_target,
            occ_evidence=occ_evidence,
            dyn_evidence=dyn_evidence,
            epi_evidence=epi_evidence,
            occ_prob=occ_prob,
            dyn_residual=dyn_residual,
            epi_variance=epi_variance,
        )
