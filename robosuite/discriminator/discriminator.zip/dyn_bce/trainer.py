from __future__ import annotations

import copy
import json
import os
from dataclasses import asdict, dataclass

import numpy as np
import torch
from torch.utils.data import DataLoader

from robosuite.discriminator.dyn_bce.losses import (
    beta_nll_loss,
    cross_covariance_penalty,
    occupancy_pu_loss,
    weighted_bce_with_logits,
)
from robosuite.discriminator.dyn_bce.metrics import compute_binary_metrics


def _to_device(batch: dict[str, torch.Tensor], device: torch.device) -> dict[str, torch.Tensor]:
    return {key: value.to(device, non_blocking=True) for key, value in batch.items()}


@dataclass
class TrainerConfig:
    device: str
    batch_size: int
    num_workers: int
    epochs: int
    learning_rate: float
    weight_decay: float
    grad_clip_norm: float
    amp: bool
    ema_decay: float
    log_every: int
    save_freq: int
    alpha_dyn: float
    eta_decor: float
    xi_fuse: float
    beta_nll: float
    occupancy_positive_prior: float
    occupancy_nnpu: bool


class DynBCETrainer:
    def __init__(
        self,
        model: torch.nn.Module,
        train_dataset,
        val_dataset,
        test_dataset,
        config: TrainerConfig,
        metadata: dict,
        cfg,
    ) -> None:
        self.model = model
        self.train_dataset = train_dataset
        self.val_dataset = val_dataset
        self.test_dataset = test_dataset
        self.config = config
        self.metadata = metadata
        self.cfg = cfg

        device_name = str(config.device)
        self.device = torch.device(device_name if torch.cuda.is_available() else "cpu")
        self.model.to(self.device)

        self.optimizer = torch.optim.AdamW(
            self.model.parameters(),
            lr=float(config.learning_rate),
            weight_decay=float(config.weight_decay),
        )
        self.scaler = torch.cuda.amp.GradScaler(
            enabled=bool(config.amp) and self.device.type == "cuda"
        )

        self.train_loader = DataLoader(
            train_dataset,
            batch_size=int(config.batch_size),
            shuffle=True,
            num_workers=int(config.num_workers),
            pin_memory=self.device.type == "cuda",
            drop_last=False,
        )
        self.val_loader = DataLoader(
            val_dataset,
            batch_size=int(config.batch_size),
            shuffle=False,
            num_workers=int(config.num_workers),
            pin_memory=self.device.type == "cuda",
            drop_last=False,
        )
        self.test_loader = DataLoader(
            test_dataset,
            batch_size=int(config.batch_size),
            shuffle=False,
            num_workers=int(config.num_workers),
            pin_memory=self.device.type == "cuda",
            drop_last=False,
        )

        self.best_val_score = float("-inf")
        self.best_state_dict: dict[str, torch.Tensor] | None = None
        self.history: dict[str, list[dict[str, float]]] = {"train": [], "val": [], "test": []}
        self.wandb_run = self._init_wandb()

    def _init_wandb(self):
        logging_cfg = getattr(self.cfg, "logging", None)
        if logging_cfg is None or not bool(getattr(logging_cfg, "use_wandb", False)):
            return None
        try:
            import wandb
        except Exception:
            print("wandb is unavailable, skipping logging.")
            return None

        entity = str(getattr(logging_cfg, "entity", "songgao-personal"))
        mode = str(getattr(logging_cfg, "mode", "offline"))
        project = str(getattr(logging_cfg, "project", "robosuite-dyn-bce"))
        os.environ.setdefault("WANDB_MODE", mode)
        os.environ.setdefault("WANDB_NAME", entity)
        return wandb.init(
            project=project,
            entity=entity,
            mode=mode,
            config={
                "trainer": asdict(self.config),
                "metadata": self.metadata,
            },
        )

    def _step(self, batch: dict[str, torch.Tensor], train: bool) -> dict[str, torch.Tensor]:
        amp_enabled = bool(self.config.amp) and self.device.type == "cuda"
        autocast_dtype = torch.float16 if self.device.type == "cuda" else torch.float32
        with torch.cuda.amp.autocast(enabled=amp_enabled, dtype=autocast_dtype):
            output = self.model(
                current_latent=batch["current_latent"],
                next_latent=batch["next_latent"],
                action_sequence=batch["action_sequence"],
                task_index=batch["task_index"],
            )
            occ_loss = occupancy_pu_loss(
                logits=output.occ_logit,
                data_type_index=batch["data_type_index"],
                sample_weights=batch["occ_weight"],
                positive_prior=float(self.config.occupancy_positive_prior),
                nnpu=bool(self.config.occupancy_nnpu),
            )
            fuse_loss = weighted_bce_with_logits(
                logits=output.judge_logit,
                targets=batch["risk_target"],
                sample_weights=batch["fuse_weight"],
            )
            dyn_loss = beta_nll_loss(
                pred_mean=output.ensemble_mean,
                pred_logvar=output.ensemble_logvar,
                target=output.ema_target,
                sample_weights=batch["dyn_weight"],
                beta=float(self.config.beta_nll),
            )
            decor_loss = cross_covariance_penalty(
                left=output.occ_private,
                right=output.dyn_private_mean,
            )
            total_loss = (
                occ_loss
                + float(self.config.alpha_dyn) * dyn_loss
                + float(self.config.eta_decor) * decor_loss
                + float(self.config.xi_fuse) * fuse_loss
            )

        if train:
            self.optimizer.zero_grad(set_to_none=True)
            self.scaler.scale(total_loss).backward()
            self.scaler.unscale_(self.optimizer)
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), float(self.config.grad_clip_norm))
            self.scaler.step(self.optimizer)
            self.scaler.update()
            self.model.update_ema(decay=float(self.config.ema_decay))

        return {
            "total_loss": total_loss.detach(),
            "occ_loss": occ_loss.detach(),
            "dyn_loss": dyn_loss.detach(),
            "decor_loss": decor_loss.detach(),
            "fuse_loss": fuse_loss.detach(),
            "occ_prob": output.occ_prob.detach(),
            "judge_prob": torch.sigmoid(output.judge_logit).detach(),
            "labels": batch["hard_label"].detach(),
        }

    def _run_epoch(self, loader: DataLoader, train: bool, epoch: int, split_name: str) -> dict[str, float]:
        self.model.train(mode=train)
        if not train:
            self.model.eval()

        loss_sums = {
            "total_loss": 0.0,
            "occ_loss": 0.0,
            "dyn_loss": 0.0,
            "decor_loss": 0.0,
            "fuse_loss": 0.0,
        }
        num_batches = 0
        occ_probs: list[np.ndarray] = []
        judge_probs: list[np.ndarray] = []
        labels: list[np.ndarray] = []

        for batch_idx, batch in enumerate(loader):
            batch = _to_device(batch, self.device)
            with torch.set_grad_enabled(train):
                outputs = self._step(batch=batch, train=train)

            for key in loss_sums:
                loss_sums[key] += float(outputs[key].item())
            occ_probs.append(outputs["occ_prob"].cpu().numpy())
            judge_probs.append(outputs["judge_prob"].cpu().numpy())
            labels.append(outputs["labels"].cpu().numpy())
            num_batches += 1

            if train and (batch_idx + 1) % max(int(self.config.log_every), 1) == 0:
                print(
                    f"epoch={epoch} split={split_name} batch={batch_idx + 1}/{len(loader)} "
                    f"loss={outputs['total_loss'].item():.4f} occ={outputs['occ_loss'].item():.4f} "
                    f"dyn={outputs['dyn_loss'].item():.4f} fuse={outputs['fuse_loss'].item():.4f}"
                )

        metrics = {
            key: value / max(num_batches, 1)
            for key, value in loss_sums.items()
        }
        label_np = np.concatenate(labels, axis=0) if labels else np.asarray([], dtype=np.int64)
        occ_np = np.concatenate(occ_probs, axis=0) if occ_probs else np.asarray([], dtype=np.float32)
        judge_np = np.concatenate(judge_probs, axis=0) if judge_probs else np.asarray([], dtype=np.float32)
        occ_metrics = compute_binary_metrics(occ_np, label_np)
        judge_metrics = compute_binary_metrics(judge_np, label_np)
        for key, value in occ_metrics.items():
            metrics[f"occ_{key}"] = float(value)
        for key, value in judge_metrics.items():
            metrics[f"judge_{key}"] = float(value)
        return metrics

    def _log_metrics(self, split_name: str, epoch: int, metrics: dict[str, float]) -> None:
        ordered = " ".join(f"{key}={value:.4f}" for key, value in sorted(metrics.items()))
        print(f"epoch={epoch} split={split_name} {ordered}")
        if self.wandb_run is not None:
            log_payload = {f"{split_name}/{key}": value for key, value in metrics.items()}
            log_payload["epoch"] = int(epoch)
            self.wandb_run.log(log_payload)

    def _checkpoint_payload(self, epoch: int) -> dict:
        return {
            "model": self.model.state_dict(),
            "cfg": self.cfg,
            "trainer_config": asdict(self.config),
            "metadata": self.metadata,
            "epoch": int(epoch),
            "history": self.history,
        }

    def fit(
        self,
        save_dir: str,
        save_name: str,
    ) -> tuple[dict[str, list[dict[str, float]]], dict[str, float]]:
        os.makedirs(save_dir, exist_ok=True)
        save_path = os.path.join(save_dir, save_name)
        stem, ext = os.path.splitext(save_name)
        if ext == "":
            ext = ".pt"

        for epoch in range(1, int(self.config.epochs) + 1):
            train_metrics = self._run_epoch(self.train_loader, train=True, epoch=epoch, split_name="train")
            val_metrics = self._run_epoch(self.val_loader, train=False, epoch=epoch, split_name="val")
            self.history["train"].append(train_metrics)
            self.history["val"].append(val_metrics)
            self._log_metrics("train", epoch, train_metrics)
            self._log_metrics("val", epoch, val_metrics)

            val_score = float(val_metrics.get("judge_f1", 0.0) + val_metrics.get("judge_auroc", 0.0))
            if val_score > self.best_val_score:
                self.best_val_score = val_score
                self.best_state_dict = copy.deepcopy(self.model.state_dict())
                best_path = os.path.join(save_dir, f"{stem}_best{ext}")
                torch.save(self._checkpoint_payload(epoch), best_path)
                print(f"Saved best checkpoint to: {best_path}")

            if int(self.config.save_freq) > 0 and epoch % int(self.config.save_freq) == 0:
                periodic_path = os.path.join(save_dir, f"{stem}_ep{epoch:04d}{ext}")
                torch.save(self._checkpoint_payload(epoch), periodic_path)
                print(f"Saved periodic checkpoint to: {periodic_path}")

        if self.best_state_dict is not None:
            self.model.load_state_dict(self.best_state_dict, strict=True)
        test_metrics = self._run_epoch(self.test_loader, train=False, epoch=int(self.config.epochs), split_name="test")
        self.history["test"].append(test_metrics)
        self._log_metrics("test", int(self.config.epochs), test_metrics)

        final_payload = self._checkpoint_payload(int(self.config.epochs))
        final_payload["test_metrics"] = test_metrics
        torch.save(final_payload, save_path)
        print(f"Saved final checkpoint to: {save_path}")

        summary_path = os.path.join(save_dir, f"{stem}_summary.json")
        with open(summary_path, "w", encoding="utf-8") as file_handle:
            json.dump(
                {
                    "history": self.history,
                    "metadata": self.metadata,
                    "best_val_score": self.best_val_score,
                    "test_metrics": test_metrics,
                },
                file_handle,
                indent=2,
                sort_keys=True,
            )
        print(f"Saved training summary to: {summary_path}")

        if self.wandb_run is not None:
            self.wandb_run.finish()
        return self.history, test_metrics
